/**
 * FoundIt - Core Logic (Zero Dependencies)
 */

// --- IndexedDB Wrapper ---
const DB_NAME = 'FoundItDB';
const DB_VERSION = 1;
const STORES = ['items', 'locations', 'containers', 'settings'];

const db = {
    instance: null,
    async init() {
        return new Promise((resolve, reject) => {
            const req = indexedDB.open(DB_NAME, DB_VERSION);
            req.onupgradeneeded = (e) => {
                const _db = e.target.result;
                STORES.forEach(store => {
                    if (!_db.objectStoreNames.contains(store)) {
                        _db.createObjectStore(store, { keyPath: 'id' });
                    }
                });
            };
            req.onsuccess = (e) => { this.instance = e.target.result; resolve(); };
            req.onerror = () => reject('DB Error');
        });
    },
    async getAll(store) {
        return new Promise(res => {
            const tx = this.instance.transaction(store, 'readonly');
            const req = tx.objectStore(store).getAll();
            req.onsuccess = () => res(req.result || []);
        });
    },
    async put(store, data) {
        return new Promise(res => {
            const tx = this.instance.transaction(store, 'readwrite');
            tx.objectStore(store).put(data);
            tx.oncomplete = () => res(true);
        });
    },
    async delete(store, id) {
        return new Promise(res => {
            const tx = this.instance.transaction(store, 'readwrite');
            tx.objectStore(store).delete(id);
            tx.oncomplete = () => res(true);
        });
    },
    async clearAll() {
        for (const store of STORES) {
            const tx = this.instance.transaction(store, 'readwrite');
            tx.objectStore(store).clear();
        }
    }
};

// --- App State ---
const state = {
    items: [],
    locations: [],
    containers: [],
    settings: { theme: 'system' },
    lastDeletedItem: null,
    undoTimeout: null
};

// --- Core App Controller ---
const app = {
    async init() {
        await db.init();
        await this.loadData();
        
        // Demo Data if empty
        if (state.locations.length === 0 && state.items.length === 0) {
            await this.seedDemoData();
            await this.loadData();
        }

        this.applyTheme(state.settings.theme);
        this.setupEventListeners();
        this.navigate('dashboard');

        // Register Service Worker
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('sw.js').catch(console.error);
        }
    },

    async loadData() {
        state.items = await db.getAll('items');
        state.locations = await db.getAll('locations');
        state.containers = await db.getAll('containers');
        const setDB = await db.getAll('settings');
        if (setDB.length > 0) state.settings = setDB[0];
    },

    setupEventListeners() {
        document.querySelectorAll('.nav-item').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const target = e.currentTarget.dataset.target;
                this.navigate(target);
            });
        });

        document.getElementById('main-search-input').addEventListener('input', (e) => {
            this.handleSearch(e.target.value.toLowerCase());
        });

        // System theme change listener
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
            if (state.settings.theme === 'system') this.applyTheme('system');
        });
    },

    navigate(viewId) {
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        document.querySelectorAll('.nav-item').forEach(v => v.classList.remove('active'));
        
        document.getElementById(`view-${viewId}`).classList.add('active');
        const navBtn = document.querySelector(`.nav-item[data-target="${viewId}"]`);
        if (navBtn) navBtn.classList.add('active');

        if (viewId === 'dashboard') this.renderDashboard();
        if (viewId === 'locations') this.renderLocationsView();
        if (viewId === 'containers') this.renderContainersView();
        if (viewId === 'favorites') this.renderFavorites();
        if (viewId === 'search') {
            document.getElementById('main-search-input').focus();
            this.handleSearch(document.getElementById('main-search-input').value.toLowerCase());
        }
        if (viewId === 'settings') {
            document.getElementById('theme-select').value = state.settings.theme;
        }
    },

    // --- UI Renderers ---
    
    renderDashboard() {
        const totalItems = state.items.length;
        const totalLocs = state.locations.length;
        const totalCont = state.containers.length;
        const totalFavs = state.items.filter(i => i.isFavorite).length;

        document.getElementById('dashboard-stats').innerHTML = `
            <div class="stat-card"><h3>${totalItems}</h3><p>Items</p></div>
            <div class="stat-card"><h3>${totalLocs}</h3><p>Locations</p></div>
            <div class="stat-card"><h3>${totalCont}</h3><p>Containers</p></div>
            <div class="stat-card"><h3>${totalFavs}</h3><p>Favorites</p></div>
        `;

        const recent = [...state.items].sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 5);
        document.getElementById('recent-items').innerHTML = recent.length ? 
            recent.map(item => this.createItemCard(item)).join('') : 
            `<div class="empty-state"><span class="empty-icon">📭</span><p>Your memory is empty. Add your first item.</p></div>`;
    },

    renderFavorites() {
        const favs = state.items.filter(i => i.isFavorite);
        document.getElementById('favorites-list').innerHTML = favs.length ? 
            favs.map(item => this.createItemCard(item)).join('') : 
            `<div class="empty-state"><span class="empty-icon">⭐</span><p>No favorites yet.</p></div>`;
    },

    // --- Search & Where Is It Logic ---

    handleSearch(query) {
        const container = document.getElementById('search-results');
        if (!query.trim()) {
            container.innerHTML = `<div class="empty-state"><span class="empty-icon">🔎</span><p>Type to search your physical memory.</p></div>`;
            return;
        }

        const results = state.items.filter(i => {
            const text = `${i.name} ${i.tags} ${i.description}`.toLowerCase();
            const locPath = this.getLocationPathString(i.locationId).toLowerCase();
            const cont = i.containerId ? state.containers.find(c => c.id === i.containerId)?.name.toLowerCase() : '';
            return text.includes(query) || locPath.includes(query) || (cont && cont.includes(query));
        });

        if (results.length === 0) {
            container.innerHTML = `<div class="empty-state"><span class="empty-icon">🤷</span><p>Nothing found. Try another item, location, or tag.</p></div>`;
            return;
        }

        // Exact match or highly specific query triggers "WHERE IS IT?" mode
        if (results.length === 1 && results[0].name.toLowerCase().includes(query)) {
            container.innerHTML = this.createWhereIsItCard(results[0]);
        } else {
            container.innerHTML = `<div class="item-list">${results.map(i => this.createItemCard(i)).join('')}</div>`;
        }
    },

    createWhereIsItCard(item) {
        const pathArr = this.getLocationPathArray(item.locationId);
        if(item.containerId) {
            const c = state.containers.find(c=>c.id === item.containerId);
            if(c) pathArr.push(`${c.icon} ${c.name}`);
        }
        
        const pathHTML = pathArr.map((node, idx) => {
            return `<span>${node}</span>${idx < pathArr.length - 1 ? '<span class="arrow">↓</span>' : ''}`;
        }).join('');

        return `
            <div class="where-is-it-card">
                <div class="where-is-it-header">${item.icon}</div>
                <div class="where-is-it-title">${item.name}</div>
                <p style="color: var(--text-muted); margin-bottom:1rem;">📍 IT IS HERE:</p>
                <div class="big-location-path">${pathHTML}</div>
                <div class="card-actions" style="justify-content:center; margin-top:2rem;">
                    <button class="btn-outline" onclick="app.editItem('${item.id}')">✏️ Edit</button>
                    <button class="btn-primary" onclick="app.toggleFav('${item.id}')">${item.isFavorite ? '⭐ Unfavorite' : '⭐ Favorite'}</button>
                </div>
            </div>
        `;
    },

    // --- Component Generators ---

    createItemCard(item) {
        const pathStr = this.getLocationPathString(item.locationId, item.containerId);
        return `
            <div class="card" onclick="if(!event.target.closest('button')) { document.getElementById('main-search-input').value='${item.name}'; app.navigate('search'); }">
                <div class="card-icon">${item.icon}</div>
                <div class="card-content">
                    <div class="card-title">${item.name}</div>
                    <div class="card-location">📍 ${pathStr}</div>
                </div>
                <div class="card-actions">
                    <button class="btn-icon ${item.isFavorite ? 'fav-active' : ''}" onclick="app.toggleFav('${item.id}')">⭐</button>
                    <button class="btn-icon" onclick="app.editItem('${item.id}')">✏️</button>
                    <button class="btn-icon" onclick="app.confirmDelete('${item.id}')">🗑️</button>
                </div>
            </div>
        `;
    },

    // --- Helpers for Locations ---

    getLocationPathArray(locId) {
        const path = [];
        let curr = state.locations.find(l => l.id === locId);
        while (curr) {
            path.unshift(curr.name);
            curr = state.locations.find(l => l.id === curr.parentId);
        }
        return path;
    },

    getLocationPathString(locId, contId = null) {
        const arr = this.getLocationPathArray(locId);
        let str = arr.map(n => `<span class="path-node">${n}</span>`).join('<span class="path-arrow">→</span>');
        if (contId) {
            const cont = state.containers.find(c => c.id === contId);
            if(cont) str += `<span class="path-arrow">→</span><span class="path-node">${cont.icon} ${cont.name}</span>`;
        }
        return str || 'Unassigned';
    },

    buildLocationOptions(selectedId = null, skipId = null) {
        // Build flat list with indentation based on depth
        const flatList = [];
        const traverse = (parentId, depth) => {
            const children = state.locations.filter(l => l.parentId === parentId);
            children.forEach(c => {
                if(c.id === skipId) return; // Prevent circular parenting
                flatList.push({ id: c.id, name: `${'&nbsp;'.repeat(depth * 4)}${depth > 0 ? '↳ ' : ''}${c.name}` });
                traverse(c.id, depth + 1);
            });
        };
        traverse(null, 0);

        return flatList.map(l => `<option value="${l.id}" ${l.id === selectedId ? 'selected' : ''}>${l.name}</option>`).join('');
    },

    // --- Modals & CRUD ---

    openItemModal() {
        document.getElementById('form-item').reset();
        document.getElementById('item-id').value = '';
        document.getElementById('modal-item-title').innerText = 'Add Item';
        document.getElementById('item-location').innerHTML = '<option value="">Select Location...</option>' + this.buildLocationOptions();
        
        const contOpts = state.containers.map(c => `<option value="${c.id}">${c.icon} ${c.name}</option>`).join('');
        document.getElementById('item-container').innerHTML = '<option value="">No Container</option>' + contOpts;
        
        document.getElementById('modal-item').showModal();
    },

    async saveItem(e) {
        e.preventDefault();
        const id = document.getElementById('item-id').value || Date.now().toString();
        const isNew = !document.getElementById('item-id').value;
        
        const item = {
            id,
            icon: document.getElementById('item-icon').value,
            name: document.getElementById('item-name').value,
            locationId: document.getElementById('item-location').value,
            containerId: document.getElementById('item-container').value || null,
            tags: document.getElementById('item-tags').value,
            description: document.getElementById('item-desc').value,
            updatedAt: Date.now(),
            createdAt: isNew ? Date.now() : state.items.find(i=>i.id===id).createdAt,
            isFavorite: isNew ? false : state.items.find(i=>i.id===id).isFavorite
        };

        await db.put('items', item);
        await this.loadData();
        document.getElementById('modal-item').close();
        this.showToast('Item saved');
        this.navigate(document.querySelector('.view.active').id.replace('view-', ''));
    },

    async editItem(id) {
        const item = state.items.find(i => i.id === id);
        if(!item) return;
        this.openItemModal();
        document.getElementById('modal-item-title').innerText = 'Edit Item';
        document.getElementById('item-id').value = item.id;
        document.getElementById('item-icon').value = item.icon;
        document.getElementById('item-name').value = item.name;
        document.getElementById('item-location').value = item.locationId;
        document.getElementById('item-container').value = item.containerId || '';
        document.getElementById('item-tags').value = item.tags;
        document.getElementById('item-desc').value = item.description || '';
    },

    async toggleFav(id) {
        const item = state.items.find(i => i.id === id);
        item.isFavorite = !item.isFavorite;
        await db.put('items', item);
        await this.loadData();
        this.navigate(document.querySelector('.view.active').id.replace('view-', ''));
    },

    confirmDelete(id) {
        if(confirm('Delete this item?')) {
            this.deleteItem(id);
        }
    },

    async deleteItem(id) {
        const item = state.items.find(i => i.id === id);
        state.lastDeletedItem = item;
        await db.delete('items', id);
        await this.loadData();
        this.navigate(document.querySelector('.view.active').id.replace('view-', ''));
        
        this.showToast('Item deleted', 'UNDO', async () => {
            if(state.lastDeletedItem) {
                await db.put('items', state.lastDeletedItem);
                state.lastDeletedItem = null;
                await this.loadData();
                this.navigate(document.querySelector('.view.active').id.replace('view-', ''));
                this.showToast('Item restored');
            }
        });
    },

    // --- Locations CRUD & UI ---
    
    renderLocationsView() {
        const map = document.getElementById('memory-map');
        
        const buildTree = (parentId) => {
            const children = state.locations.filter(l => l.parentId === parentId);
            if (children.length === 0) return '';
            
            let html = '<ul>';
            children.forEach(c => {
                const itemsCount = state.items.filter(i => i.locationId === c.id).length;
                html += `
                    <li>
                        <div class="loc-node" onclick="app.handleSearch('${c.name.toLowerCase()}')">
                            📍 ${c.name} <small style="color:var(--text-muted)">(${itemsCount} items)</small>
                        </div>
                        ${buildTree(c.id)}
                    </li>
                `;
            });
            html += '</ul>';
            return html;
        };

        const roots = buildTree(null);
        map.innerHTML = roots || `<div class="empty-state"><p>No locations created yet.</p></div>`;
    },

    openLocationModal() {
        document.getElementById('form-location').reset();
        document.getElementById('loc-parent').innerHTML = '<option value="">None (Top Level)</option>' + this.buildLocationOptions();
        document.getElementById('modal-location').showModal();
    },

    async saveLocation(e) {
        e.preventDefault();
        const loc = {
            id: Date.now().toString(),
            name: document.getElementById('loc-name').value,
            parentId: document.getElementById('loc-parent').value || null
        };
        await db.put('locations', loc);
        await this.loadData();
        document.getElementById('modal-location').close();
        this.renderLocationsView();
        this.showToast('Location saved');
    },

    // --- Containers CRUD & UI ---

    renderContainersView() {
        const grid = document.getElementById('container-list');
        if(state.containers.length === 0) {
            grid.innerHTML = `<div class="empty-state" style="grid-column: 1/-1"><p>No containers yet.</p></div>`;
            return;
        }

        grid.innerHTML = state.containers.map(c => {
            const count = state.items.filter(i => i.containerId === c.id).length;
            const locName = this.getLocationPathString(c.locationId);
            return `
                <div class="cont-card" onclick="app.handleSearch('${c.name.toLowerCase()}')">
                    <div class="icon">${c.icon}</div>
                    <h4>${c.name}</h4>
                    <p>📍 ${locName}</p>
                    <p style="margin-top:0.5rem; font-weight:bold;">${count} Items</p>
                </div>
            `;
        }).join('');
    },

    openContainerModal() {
        document.getElementById('form-container').reset();
        document.getElementById('cont-location').innerHTML = '<option value="">Select Location...</option>' + this.buildLocationOptions();
        document.getElementById('modal-container').showModal();
    },

    async saveContainer(e) {
        e.preventDefault();
        const cont = {
            id: Date.now().toString(),
            icon: document.getElementById('cont-icon').value,
            name: document.getElementById('cont-name').value,
            locationId: document.getElementById('cont-location').value
        };
        await db.put('containers', cont);
        await this.loadData();
        document.getElementById('modal-container').close();
        this.renderContainersView();
        this.showToast('Container saved');
    },

    // --- Settings & Utils ---

    async changeTheme(val) {
        state.settings.theme = val;
        await db.put('settings', { id: 'settings', theme: val });
        this.applyTheme(val);
    },

    applyTheme(theme) {
        if (theme === 'system') {
            const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
        } else {
            document.documentElement.setAttribute('data-theme', theme);
        }
    },

    showToast(msg, btnText = null, action = null) {
        if(state.undoTimeout) clearTimeout(state.undoTimeout);
        const t = document.getElementById('toast');
        let html = `<span>${msg}</span>`;
        if (btnText) html += `<button class="toast-btn" id="toast-action">${btnText}</button>`;
        t.innerHTML = html;
        t.classList.add('show');
        
        if (btnText && action) {
            document.getElementById('toast-action').onclick = () => {
                action();
                t.classList.remove('show');
            };
        }

        state.undoTimeout = setTimeout(() => {
            t.classList.remove('show');
        }, 4000);
    },

    async exportData() {
        const data = {
            items: state.items,
            locations: state.locations,
            containers: state.containers
        };
        const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `foundit_backup_${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
    },

    importData(e) {
        const file = e.target.files[0];
        if(!file) return;
        const reader = new FileReader();
        reader.onload = async (ev) => {
            try {
                const data = JSON.parse(ev.target.result);
                if(data.items && data.locations) {
                    if(confirm('Importing data will replace existing data. Continue?')) {
                        await db.clearAll();
                        for(const l of data.locations) await db.put('locations', l);
                        for(const c of (data.containers || [])) await db.put('containers', c);
                        for(const i of data.items) await db.put('items', i);
                        await this.loadData();
                        this.navigate('dashboard');
                        this.showToast('Data imported successfully');
                    }
                }
            } catch(err) {
                alert('Invalid backup file');
            }
        };
        reader.readAsText(file);
    },

    async clearAllData() {
        if(confirm('WARNING: This will delete all your local data forever. Are you absolutely sure?')) {
            await db.clearAll();
            await this.loadData();
            this.navigate('dashboard');
            this.showToast('All data cleared');
        }
    },

    async seedDemoData() {
        const l1 = { id: 'l1', name: 'Home', parentId: null };
        const l2 = { id: 'l2', name: 'Study Room', parentId: 'l1' };
        const l3 = { id: 'l3', name: 'Desk', parentId: 'l2' };
        const l4 = { id: 'l4', name: 'Drawer 2', parentId: 'l3' };
        await db.put('locations', l1); await db.put('locations', l2);
        await db.put('locations', l3); await db.put('locations', l4);

        const c1 = { id: 'c1', icon: '🎒', name: 'School Bag', locationId: 'l2' };
        await db.put('containers', c1);

        await db.put('items', {
            id: 'i1', icon: '🧮', name: 'Black Calculator', locationId: 'l4', containerId: null, tags: 'math, school', description: 'Casio Scientific', updatedAt: Date.now(), createdAt: Date.now(), isFavorite: true
        });
        await db.put('items', {
            id: 'i2', icon: '🔑', name: 'House Keys', locationId: 'l1', containerId: null, tags: 'daily', description: '', updatedAt: Date.now(), createdAt: Date.now(), isFavorite: false
        });
        await db.put('items', {
            id: 'i3', icon: '📘', name: 'Maths Notes', locationId: 'l2', containerId: 'c1', tags: 'school', description: '', updatedAt: Date.now(), createdAt: Date.now(), isFavorite: false
        });
    }
};

window.onload = () => app.init();
